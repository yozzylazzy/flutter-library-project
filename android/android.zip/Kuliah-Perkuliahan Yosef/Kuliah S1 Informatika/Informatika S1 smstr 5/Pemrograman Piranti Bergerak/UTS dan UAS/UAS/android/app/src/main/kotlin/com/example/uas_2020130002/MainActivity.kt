package com.example.uas_2020130002

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
