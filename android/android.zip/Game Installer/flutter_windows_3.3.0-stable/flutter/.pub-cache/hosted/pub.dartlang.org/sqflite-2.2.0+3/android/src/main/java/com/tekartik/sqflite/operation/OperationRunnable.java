package com.tekartik.sqflite.operation;

/**
 * Operation runnable interface
 */
public interface OperationRunnable {
    boolean run();
}
