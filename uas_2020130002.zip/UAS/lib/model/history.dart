
class History{
  String idhistory;
  String idbuku;
  String namabuku;
  String jenis;
  String penulis;
  String tahunterbit;
  String idpeminjaman;
  DateTime tglpeminjaman;
  History(this.idhistory, this.idbuku, this.namabuku, this.jenis, this.penulis,
      this.tahunterbit, this.idpeminjaman, this.tglpeminjaman);
}