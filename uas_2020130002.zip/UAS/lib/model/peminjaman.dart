class Peminjaman{
  String idpeminjaman;
  String npm;
  DateTime tglpinjam;
  DateTime tglkembali;

  Peminjaman(this.idpeminjaman,this.npm,this.tglpinjam,this.tglkembali);

}