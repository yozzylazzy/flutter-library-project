class Anggota{
  final String npm;
  final String nama;
  final String email;
  final String notelp;
  final DateTime tglgabung;
  final String password;

  Anggota(this.npm, this.nama, this.email, this.notelp, this.tglgabung, this.password);
}