class Buku{
  final int id;
  final String title;
  final String penulis;
  final String jenisbuku;
  final int halaman;

  Buku(this.id,this.title,this.penulis,this.jenisbuku,this.halaman);
}